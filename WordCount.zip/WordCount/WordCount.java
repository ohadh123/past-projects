/*
 * This program counts the number of characters, words, sentences, and paragraphs
 * in any specified .txt file
 * @author Ohad Koronyo - Dec. 4, 2015
 */
import java.io.*;

public class WordCount 
{
    /**
     * The main method contains all necessary code for the counter class
     * Pre-conditions: User types in java WordCount followed by two arguments:
     *                      -[c][w][s][p] and filename
     *                 Example of User invoking class: java WordCount -cw temp.txt
     * Post-Conditions: The method prints out all of the written material in the document,
     *                  in addition to the counts that the User specified
     * @param args 
     */
    public static void main(String [] args)
    {
        String fileName;//initializes file name variable
        
        //Gets the name of the .txt file from invoking the program
        int testIfThereIsNoCWSP = args.length;
        if (testIfThereIsNoCWSP == 1)
            fileName = args[0];//if there is no cwsp statement, the file name is the first argument
        else
            fileName = args[1];//if there is a cwsp statement, the file name is the second argument
        
        //Sets lines to null so as to reference each line at a time
        String line = null;
        
        //opens try catch expression because we need to account for errors at the end
        try 
        {
            //Reads text files in the default encoding
            FileReader fileReader = new FileReader(fileName);

            //Wraps FileReader in BufferedReader so as to ensure scanning of document
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            
            //initializes counting variables
            int charCount = 0;//characters
            int wordCount = 0;//words
            int sentCount = 0;//sentences
            int parCount = 0;//paragraphs
            
            System.out.println();
            //runs while loop for as long as lines are present in document
            while((line = bufferedReader.readLine()) != null)
            {
                //prints out document
                System.out.println(line);
                
                //counts characters based on the char length of each line (then adds them up)
                charCount += line.length();
                
                //counts words based on number of spaces (accounts for spaces at beginning of sentences)
                boolean prevSpace=true;//initialize prevSpace
                //loops to find all spaces throughout the lines
                for (int i = 0; i < line.length(); i++) 
                {
                    if (line.charAt(i) == ' ') 
                        prevSpace=true;//if space was the previous character, the object is set as true
                    else //works to not include spaces at beginning of sentences
                        {
                            if(prevSpace) 
                                wordCount++;//adds word per space
                            prevSpace = false;//resets prevSpace so as to only count one word per space
                        }
                }
                
                //counts sentences based on occurence of period char
                for (int i = 0; i < line.length(); i++)
                    if(line.charAt(i) == '.')
                        sentCount++;
                
                //counts paragraphs based on number of lines
                parCount++;//adds one paragraph per each line in document 
                           //lines are only broken by a linefeed, and so are paragraphs, so they are a perfect match
            }
            System.out.println(); 
                    
            //if the user leaves the counts blank, prints out all of the counts
            if (testIfThereIsNoCWSP == 1)
                {
                    System.out.println("Character Count: " + charCount);
                    System.out.println("Word Count: " + wordCount);
                    System.out.println("Sentence Count: " + sentCount);
                    System.out.println("Paragraph Count: " + parCount);
                }
            else
                {
                    //determines which counts to produce based on -[c][w][s][p] argument
                if (args[0].indexOf('c') >= 0)
                    System.out.println("Character Count: " + charCount);
                if (args[0].indexOf('w') >= 0)
                    System.out.println("Word Count: " + wordCount);
                if (args[0].indexOf('s') >= 0)
                    System.out.println("Sentence Count: " + sentCount);
                if (args[0].indexOf('p') >= 0)
                    System.out.println("Paragraph Count: " + parCount);
                }
            
            //Closes file to ensure safety of document
            bufferedReader.close();         
        }
        //catches error for if the file name does not match a file
        catch(FileNotFoundException ex)
        {
            System.out.println("Unable to open file " + fileName);                
        }
        //accounts for other errrs
        catch(IOException ex) 
        {
            System.out.println("Error reading file " + fileName);                  
        }
    }
}
