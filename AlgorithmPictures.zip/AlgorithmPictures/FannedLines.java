/**
* This program draws fanned lines from all four corners
* of the screen
*@author Ohad Koronyo - Oct. 24, 2015
* 
*/

import java.awt.Graphics; 
import javax.swing.JPanel;
import javax.swing.JFrame;

public class FannedLines extends JPanel
{
    public static void main(String[] args)
    {
        // creates a panel that contains drawing
        FannedLines panel = new FannedLines();
        
        // creates a new frame to hold the panel
        JFrame application = new JFrame();
        
        // set the frame to exit when it is closed
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        application.add(panel); // add the panel to the frame
        application.setSize(650, 650); // set the size of the frame
        application.setVisible(true); // make the frame visible
    }
    
    // this method fans lines from the upper-left hand corner
    public void paintComponent(Graphics g)
    {
        // calls paintComponent to ensure the panel displays correctly
        super.paintComponent(g);
    
        int width = getWidth();// total width 
        int height = getHeight();// total height 
        
        // Draws 14 lines from the upper-left hand corner
        /* The endpoint of any line increases by dividing the width 
        * and height by a factor of 15 and subtracting that from the original
        * width and height
        */
        g.drawLine(0, 0, width - (14*(width/15)), height - ((height/15)));
        g.drawLine(0, 0, width - (13*(width/15)), height - (2*(height/15)));
        g.drawLine(0, 0, width - (12*(width/15)), height - (3*(height/15)));
        g.drawLine(0, 0, width - (11*(width/15)), height - (4*(height/15)));
        g.drawLine(0, 0, width - (10*(width/15)), height - (5*(height/15)));
        g.drawLine(0, 0, width - (9*(width/15)), height - (6*(height/15)));
        g.drawLine(0, 0, width - (8*(width/15)), height - (7*(height/15)));
        g.drawLine(0, 0, width - (7*(width/15)), height - (8*(height/15)));
        g.drawLine(0, 0, width - (6*(width/15)), height - (9*(height/15)));
        g.drawLine(0, 0, width - (5*(width/15)), height - (10*(height/15)));
        g.drawLine(0, 0, width - (4*(width/15)), height - (11*(height/15)));
        g.drawLine(0, 0, width - (3*(width/15)), height - (12*(height/15)));
        g.drawLine(0, 0, width - (2*(width/15)), height - (13*(height/15)));
        g.drawLine(0, 0, width - ((width/15)), height - (14*(height/15)));
        
        // draws 14 lines from the upper-right hand corner
        /* The endpoint of any line increases by dividing the width 
        * and height by a factor of 15 and subtracting that from the original
        * width and height
        */
        g.drawLine(width, 0, width - ((width/15)), height - ((height/15)));
        g.drawLine(width, 0, width - (2*(width/15)), height - (2*(height/15)));
        g.drawLine(width, 0, width - (3*(width/15)), height - (3*(height/15)));
        g.drawLine(width, 0, width - (4*(width/15)), height - (4*(height/15)));
        g.drawLine(width, 0, width - (5*(width/15)), height - (5*(height/15)));
        g.drawLine(width, 0, width - (6*(width/15)), height - (6*(height/15)));
        g.drawLine(width, 0, width - (7*(width/15)), height - (7*(height/15)));
        g.drawLine(width, 0, width - (8*(width/15)), height - (8*(height/15)));
        g.drawLine(width, 0, width - (9*(width/15)), height - (9*(height/15)));
        g.drawLine(width, 0, width - (10*(width/15)), height - (10*(height/15)));
        g.drawLine(width, 0, width - (11*(width/15)), height - (11*(height/15)));
        g.drawLine(width, 0, width - (12*(width/15)), height - (12*(height/15)));
        g.drawLine(width, 0, width - (13*(width/15)), height - (13*(height/15)));
        g.drawLine(width, 0, width - (14*(width/15)), height - (14*(height/15)));
        
        // draws 14 lines from the lower-right hand corner
        /* The endpoint of any line increases by dividing the width 
        * and height by a factor of 15 and subtracting that from the original
        * width and height
        */
        g.drawLine(width, height, width - (14*(width/15)), height - ((height/15)));
        g.drawLine(width, height, width - (13*(width/15)), height - (2*(height/15)));
        g.drawLine(width, height, width - (12*(width/15)), height - (3*(height/15)));
        g.drawLine(width, height, width - (11*(width/15)), height - (4*(height/15)));
        g.drawLine(width, height, width - (10*(width/15)), height - (5*(height/15)));
        g.drawLine(width, height, width - (9*(width/15)), height - (6*(height/15)));
        g.drawLine(width, height, width - (8*(width/15)), height - (7*(height/15)));
        g.drawLine(width, height, width - (7*(width/15)), height - (8*(height/15)));
        g.drawLine(width, height, width - (6*(width/15)), height - (9*(height/15)));
        g.drawLine(width, height, width - (5*(width/15)), height - (10*(height/15)));
        g.drawLine(width, height, width - (4*(width/15)), height - (11*(height/15)));
        g.drawLine(width, height, width - (3*(width/15)), height - (12*(height/15)));
        g.drawLine(width, height, width - (2*(width/15)), height - (13*(height/15)));
        g.drawLine(width, height, width - ((width/15)), height - (14*(height/15)));
        
        // draws 14 lines from the lower-left hand corner
        /* The endpoint of any line decreases by dividing the width 
        * and height by a factor of 15 and subtracting that from the original
        * width and height
        */
        g.drawLine(0, height, width - (14*(width/15)), height - (14*(height/15)));
        g.drawLine(0, height, width - (13*(width/15)), height - (13*(height/15)));
        g.drawLine(0, height, width - (12*(width/15)), height - (12*(height/15)));
        g.drawLine(0, height, width - (11*(width/15)), height - (11*(height/15)));
        g.drawLine(0, height, width - (10*(width/15)), height - (10*(height/15)));
        g.drawLine(0, height, width - (9*(width/15)), height - (9*(height/15)));
        g.drawLine(0, height, width - (8*(width/15)), height - (8*(height/15)));
        g.drawLine(0, height, width - (7*(width/15)), height - (7*(height/15)));
        g.drawLine(0, height, width - (6*(width/15)), height - (6*(height/15)));
        g.drawLine(0, height, width - (5*(width/15)), height - (5*(height/15)));
        g.drawLine(0, height, width - (4*(width/15)), height - (4*(height/15)));
        g.drawLine(0, height, width - (3*(width/15)), height - (3*(height/15)));
        g.drawLine(0, height, width - (2*(width/15)), height - (2*(height/15)));
        g.drawLine(0, height, width - ((width/15)), height - ((height/15)));
        
    }
}
