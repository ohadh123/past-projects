/**
* This program draws a circular spiral
*@author Ohad Koronyo - Nov. 10, 2015
* 
*/
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.lang.Math;

public class CircularSpiral extends JPanel
{
    /*
    The main method displays the drawing of the circular semicircle
    */
    public static void main(String[] args)
    {
        // creates a panel that contains drawing
        CircularSpiral panel = new CircularSpiral();
        
        // creates a new frame to hold the panel
        JFrame application = new JFrame();
        
        // set the frame to exit when it is closed
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        application.add(panel); // add the panel to the frame
        application.setSize(650, 650); // set the size of the frame
        application.setVisible(true); // make the frame visible
        
    }
    /*
    This method draws the semicircles that compose the spiral
    
    Pre-Conditions: Graphics g
    Post-Conditions: startX, startY, width, length, and degree are real number integers
                    draws semicircles to fill screen with a spiral 
    */
    
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);// calls paintComponent to ensure the panel displays correctly
        
        //initialize variables with values 
        int Width = getWidth();// total width 
        int height = getHeight();// total height 
        
        int startX = Width/2;//x coordinate for starting point of arc
        int startY = height/2 - 10;//y coordinate for starting point of arc
        int width = 20;//width of arc rectangle
        int length = 20;//length of arc
        int degree = 180;//degree span of arc
        
        //draws first arc 
        g.drawArc(startX, startY, width, length, 0, degree);
        
        //loops to draw remaining arcs
        for(int counter = 0; counter < 100; counter++ )
        {
            
            startY -= 10;
            width += 20;
            length += 20;
            degree = -degree;//degree sign flips for every next semicircle
            
           if (counter%2 == 0)//even arcs
                startX -= 20;//startX only changes every other semicircle
            
            
            g.drawArc(startX, startY, width, length, 0, degree);//draws arc with given components
             
        }
    }
}
