/**
* This program draws lines that form a curve from all sides
* of the screen
*@author Ohad Koronyo - Oct. 24, 2015
* 
*/

import java.awt.Graphics; 
import javax.swing.JPanel;
import javax.swing.JFrame;

public class CurvedEdges extends JPanel
{
    public static void main(String[] args)
    {
        // creates a panel that contains drawing
        CurvedEdges panel = new CurvedEdges();
        
        // creates a new frame to hold the panel
        JFrame application = new JFrame();
        
        // sets the frame to exit when it is closed
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        application.add(panel); // adds the panel to the frame
        application.setSize(650, 650); // sets the size of the frame
        application.setVisible(true); // makes the frame visible
    }
    
    // this method draws lines that form a curve in the bottom-left hand corner
    public void paintComponent(Graphics g)
    {
        // calls paintComponent to ensure the panel displays correctly
        super.paintComponent(g);
    
        int width = getWidth();// total width 
        int height = getHeight();// total height 
        
        // Draws 15 lines starting from the upper-left hand corner and descending counterclockwise
        /* The two endpoints of any line are decided by moving down one increment 
        * on the left edge and right one increment on the bottom edge.
        * Increments are factors of 15 of width or height
        */
        g.drawLine(0, 0, width - (14*(width/15)), height);
        g.drawLine(0, height - (14*(height/15)), width - (13*(width/15)), height);
        g.drawLine(0, height - (13*(height/15)), width - (12*(width/15)), height);
        g.drawLine(0, height - (12*(height/15)), width - (11*(width/15)), height);
        g.drawLine(0, height - (11*(height/15)), width - (10*(width/15)), height);
        g.drawLine(0, height - (10*(height/15)), width - (9*(width/15)), height);
        g.drawLine(0, height - (9*(height/15)), width - (8*(width/15)), height);
        g.drawLine(0, height - (8*(height/15)), width - (7*(width/15)), height);
        g.drawLine(0, height - (7*(height/15)), width - (6*(width/15)), height);
        g.drawLine(0, height - (6*(height/15)), width - (5*(width/15)), height);
        g.drawLine(0, height - (5*(height/15)), width - (4*(width/15)), height);
        g.drawLine(0, height - (4*(height/15)), width - (3*(width/15)), height);
        g.drawLine(0, height - (3*(height/15)), width - (2*(width/15)), height);
        g.drawLine(0, height - (2*(height/15)), width - ((width/15)), height);
        g.drawLine(0, height - ((height/15)), width, height);
        
        // Draws 15 lines starting from the upper-left hand corner and descending clockwise
        /* The two endpoints of any line are decided by moving right one increment 
        * on the top edge and down one increment on the right edge.
        * Increments are factors of 15 of width or height
        */
        g.drawLine(0, 0, width, height - (14*(height/15)));
        g.drawLine(width - (14*(width/15)), 0, width, height - (13*(height/15)));
        g.drawLine(width - (13*(width/15)), 0, width, height - (12*(height/15)));
        g.drawLine(width - (12*(width/15)), 0, width, height - (11*(height/15)));
        g.drawLine(width - (11*(width/15)), 0, width, height - (10*(height/15)));
        g.drawLine(width - (10*(width/15)), 0, width, height - (9*(height/15)));
        g.drawLine(width - (9*(width/15)), 0, width, height - (8*(height/15)));
        g.drawLine(width - (8*(width/15)), 0, width, height - (7*(height/15)));
        g.drawLine(width - (7*(width/15)), 0, width, height - (6*(height/15)));
        g.drawLine(width - (6*(width/15)), 0, width, height - (5*(height/15)));
        g.drawLine(width - (5*(width/15)), 0, width, height - (4*(height/15)));
        g.drawLine(width - (4*(width/15)), 0, width, height - (3*(height/15)));
        g.drawLine(width - (3*(width/15)), 0, width, height - (2*(height/15)));
        g.drawLine(width - (2*(width/15)), 0, width, height - ((height/15)));
        g.drawLine(width - ((width/15)), 0, width, height);
        
        
        // Draws 15 lines starting from the bottom-left hand corner and ascending counterclockwise
        /* The two endpoints of any line are decided by moving right one increment 
        * on the bottom edge and up one increment on the right edge.
        * Increments are factors of 15 of width or height
        */
        g.drawLine(0, height, width, height - ((height/15)));
        g.drawLine(width - (14*(width/15)), height, width, height - (2*(height/15)));
        g.drawLine(width - (13*(width/15)), height, width, height - (3*(height/15)));
        g.drawLine(width - (12*(width/15)), height, width, height - (4*(height/15)));
        g.drawLine(width - (11*(width/15)), height, width, height - (5*(height/15)));
        g.drawLine(width - (10*(width/15)), height, width, height - (6*(height/15)));
        g.drawLine(width - (9*(width/15)), height, width, height - (7*(height/15)));
        g.drawLine(width - (8*(width/15)), height, width, height - (8*(height/15)));
        g.drawLine(width - (7*(width/15)), height, width, height - (9*(height/15)));
        g.drawLine(width - (6*(width/15)), height, width, height - (10*(height/15)));
        g.drawLine(width - (5*(width/15)), height, width, height - (11*(height/15)));
        g.drawLine(width - (4*(width/15)), height, width, height - (12*(height/15)));
        g.drawLine(width - (3*(width/15)), height, width, height - (13*(height/15)));
        g.drawLine(width - (2*(width/15)), height, width, height - (14*(height/15)));
        g.drawLine(width - ((width/15)), height, width, 0);
        
        // Draws 15 lines starting from the bottom-left hand corner and ascending clockwise
        /* The two endpoints of any line are decided by moving up one increment 
        * on the left edge and right one increment on the top edge.
        * Increments are factors of 15 of width or height
        */
        g.drawLine(0, height, width - (14*(width/15)), 0);
        g.drawLine(0, height - ((height/15)), width - (13*(width/15)), 0);
        g.drawLine(0, height - (2*(height/15)), width - (12*(width/15)), 0);
        g.drawLine(0, height - (3*(height/15)), width - (11*(width/15)), 0);
        g.drawLine(0, height - (4*(height/15)), width - (10*(width/15)), 0);
        g.drawLine(0, height - (5*(height/15)), width - (9*(width/15)), 0);
        g.drawLine(0, height - (6*(height/15)), width - (8*(width/15)), 0);
        g.drawLine(0, height - (7*(height/15)), width - (7*(width/15)), 0);
        g.drawLine(0, height - (8*(height/15)), width - (6*(width/15)), 0);
        g.drawLine(0, height - (9*(height/15)), width - (5*(width/15)), 0);
        g.drawLine(0, height - (10*(height/15)), width - (4*(width/15)), 0);
        g.drawLine(0, height - (11*(height/15)), width - (3*(width/15)), 0);
        g.drawLine(0, height - (12*(height/15)), width - (2*(width/15)), 0);
        g.drawLine(0, height - (13*(height/15)), width - (1*(width/15)), 0);
        g.drawLine(0, height - (14*(height/15)), width, 0);
        
    }
}
