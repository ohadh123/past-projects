/*
 * This program simulates a random dice roll
 * @author Ohad Koronyo - Nov. 8, 2015
 */
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.lang.Math;
import java.security.SecureRandom;

public class DoubleDiceSimulation extends JPanel
{
    public static void main(String[] args)
    {
        // creates a panel that contains drawing
        DoubleDiceSimulation panel = new DoubleDiceSimulation();
        
        // creates a new frame to hold the panel
        JFrame application = new JFrame();
        
        // set the frame to exit when it is closed
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        application.add(panel); // add the panel to the frame
        application.setSize(450, 250); // set the size of the frame
        application.setVisible(true); // make the frame visible
    }
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        SecureRandom randomNumbers = new SecureRandom();
        int randomRoll = 1 + randomNumbers.nextInt(6);
        int randomRoll2 = 1 + randomNumbers.nextInt(6);
        System.out.println(randomRoll + " " + randomRoll2);
        
        g.setColor(Color.RED);
        g.fillRect(45, 35, 160, 160);
        g.fillRect(250, 35, 160, 160);
        
        g.setColor(Color.WHITE);
        switch(randomRoll)
        {
            case 1:
                g.fillOval(115, 105, 20, 20);
                break;
            case 2:
                g.fillOval(75, 65, 20, 20);
                g.fillOval(155, 145, 20, 20);
                break;
            case 3:
                g.fillOval(115, 105, 20, 20);
                g.fillOval(75, 65, 20, 20);
                g.fillOval(155, 145, 20, 20);
                break;
            case 4:
                g.fillOval(75, 65, 20, 20);
                g.fillOval(155, 145, 20, 20);
                g.fillOval(155, 65, 20, 20);
                g.fillOval(75,145, 20, 20);
                break;
            case 5:
                g.fillOval(115, 105, 20, 20);
                g.fillOval(75, 65, 20, 20);
                g.fillOval(155, 145, 20, 20);
                g.fillOval(155, 65, 20, 20);
                g.fillOval(75,145, 20, 20);
                break;
            case 6:
                g.fillOval(75, 65, 20, 20);
                g.fillOval(155, 145, 20, 20);
                g.fillOval(155, 65, 20, 20);
                g.fillOval(75,145, 20, 20);
                g.fillOval(75, 105, 20, 20);
                g.fillOval(155, 105, 20, 20);
                break;
                
        }
        switch(randomRoll2)
        {
            case 1:
                g.fillOval(320, 105, 20, 20);
                break;
            case 2:
                g.fillOval(280, 65, 20, 20);
                g.fillOval(360, 145, 20, 20);
                break;
            case 3:
                g.fillOval(320, 105, 20, 20);
                g.fillOval(280, 65, 20, 20);
                g.fillOval(360, 145, 20, 20);
                break;
            case 4:
                g.fillOval(280, 65, 20, 20);
                g.fillOval(360, 145, 20, 20);
                g.fillOval(360, 65, 20, 20);
                g.fillOval(280,145, 20, 20);
                break;
            case 5:
                g.fillOval(320, 105, 20, 20);
                g.fillOval(280, 65, 20, 20);
                g.fillOval(360, 145, 20, 20);
                g.fillOval(360, 65, 20, 20);
                g.fillOval(280,145, 20, 20);
                break;
            case 6:
                g.fillOval(280, 65, 20, 20);
                g.fillOval(360, 145, 20, 20);
                g.fillOval(360, 65, 20, 20);
                g.fillOval(280,145, 20, 20);
                g.fillOval(280, 105, 20, 20);
                g.fillOval(360, 105, 20, 20);
                break;
                
        }
    }
}
