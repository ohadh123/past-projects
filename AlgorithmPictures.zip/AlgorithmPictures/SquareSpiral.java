/**
* This program draws a square-shaped spiral
*@author Ohad Koronyo - Nov. 10, 2015
* 
*/
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.lang.Math;

public class SquareSpiral extends JPanel
{
    /*
    The main method displays the drawing of the square-shaped spiral
    */
    public static void main(String[] args)
    {
        // creates a panel that contains drawing
        SquareSpiral panel = new SquareSpiral();
        
        // creates a new frame to hold the panel
        JFrame application = new JFrame();
        
        // set the frame to exit when it is closed
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        application.add(panel); // add the panel to the frame
        application.setSize(650, 650); // set the size of the frame
        application.setVisible(true); // make the frame visible
        
    }
    /*
    This method draws the lines to create the square-shaped spiral
    
    Pre-Conditions: Graphics g
    
    Post-Conditions: startX, startY, endX, endY, and the increment variables are real number integers
                     method runs and draws the clockwise-oriented lines
    */
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);// calls paintComponent to ensure the panel displays correctly
        
        //input value here to rescale the drawing
        int rescale = 8;
        

        //when panel resizes, so does the picture
        int width = getWidth();// total width 
        int height = getHeight();// total height 
        
        //initializse starting points
        int startX = width/2;//x coordinate of starting point
        int startY = height/2;//y coorinate of starting point
        int endX = width/2;//x coordinate of end point
        int endY = height/2 + rescale;//y coordinate of end point
        
        int line[] = {startX, startY, endX, endY};//initializes array for easier use
        
        //increments are used for increasing the lengths of lines 
        int increment1 = rescale;
        int increment2 = rescale;
        int increment3 = rescale;
        
        //loops 100 times to draw 100 lines
        //the for loop uses several patterns which facilitate in determining coordinates of the lines
        for(int counter = 1; counter < 10000; counter++)
        {
            
            if (counter%2 == 0)//even lines
            {
                line[1]+=increment1;
                line[2]-=increment1;
            }
            if ((counter-1)%2 == 0 && counter != 1)//odd lines
            {
                line[0]-=increment2;
                line[3]-=increment3;
            }

            g.drawLine(line[0], line[1], line[2], line[3]);//draws line
            
            //the following lines change the increments accordingly
            if (counter%2 == 0 && increment1 > 0)//even line and increment is +
                increment1 = -(Math.abs(increment1) + rescale);//increase by 25
            else if (counter%2 == 0 && increment1 < 0)//even line and increment is -
                increment1 = (Math.abs(increment1) + rescale);//increase by 25
            if ((counter-1)%2 == 0 && increment2 > 0 && counter != 1)//odd line and increment is +
                increment2 = -(Math.abs(increment2) + rescale);//increase by 25
            else if ((counter-1)%2 == 0 && increment2 < 0 && counter != 1)//odd line and increment is -
                increment2 = (Math.abs(increment2) + rescale);//increase by 25
            if(increment2 < 0)//when increment2 is -, increment3 is - as well
                increment3 = increment2 - rescale;//increase by 25
            else if(increment2 > 0)// increment2 is +, increment3 is + as well
                increment3 = increment2 + rescale;//increase by 25
        }
    }
}