/**
* This program draws 10 random filled shapes in random colors, positions, and sizes
*@author Ohad Koronyo - Nov. 8, 2015
* 
*/
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class RandomShapes extends JPanel
{
    /*
    The main method displays the drawing of the 10 random figures on a frame
    */
    public static void main(String[] args)
    {
        // creates a panel that contains drawing
        RandomShapes panel = new RandomShapes();
        
        // creates a new frame to hold the panel
        JFrame application = new JFrame();
        
        // set the frame to exit when it is closed
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        application.add(panel); // add the panel to the frame
        application.setSize(650, 650); // set the size of the frame
        application.setVisible(true); // make the frame visible
    }
    /*
    This method draws 10 random filled shapes in random colors, positions, and sizes.
    
    Pre-Conditions: Graphics g is built-in java class variable
    Post-Conditions: width and height are integers based on the panel's current size
                     integers X and Y are real numbers, representing starting point coordinates,
                        no greater than the current width or height
                     integers horizontalLength and verticalLength are real numbers, representing 
                        the width and height of each shape, no greater than half the 
                        width or height ofthe window
                     double rectOrOval is a real number between 1-2
                     
    */
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);// calls paintComponent to ensure the panel displays correctly
        int R = 0;//initializes red component
        int G = 0;//initializes green component
        int B = 0;//initalizes blue component
        
        int width = getWidth();// total width 
        int height = getHeight();// total height 
        
        //iterates 10 times so as to draw 10 shapes
        for(int x = 1; x<=10; x++)
        {
            Color color1 = RandomShapes.Color(R, G, B);//retrieves first random color from Color() method
            g.setColor(color1);//sets the color to the randomly generated color
            
            int X = (int)(Math.random()*width);//generates random x-coordinate
            int Y = (int)(Math.random()*height);//generates random y-coordinate
            int horizontalLength = (int)((Math.random()*width)/2);//generates random horizontal length for figure (no greater than half the width of window)
            int verticalLength = (int)((Math.random()*height)/2);//generates random vertical length for figure (no greater than half the length of window)
            
            double rectOrOval = 1+Math.random();//generates random number to decide whether to create a rectangle or oval
            
            //based on previous number, decides which shape to draw
            if(rectOrOval>=1.5)//equal probability
                g.fillOval(X, Y, horizontalLength, verticalLength);//draws oval with given components
            else
                g.fillRect(X, Y, horizontalLength, verticalLength);//draws rectangle with given components
                
        }
        System.out.println("All Done!");
    }
    /*
    This method generates the random colors
    
    Pre-Conditions: color component R, G, and B are integers from 0-255
    Post-Conditions: color is randomly generated and consists of red,
    green, and blue components from 0-255 each
    */
    public static Color Color(int R, int G, int B)
    {
        R = (int)(1+Math.random()*255);//generates random number for Red component
        G = (int)(1+Math.random()*255);//generates random number for Green component
        B = (int)(1+Math.random()*255);//generates random number for Blue component
        Color color = new Color(R,G,B);//makes the random color from the random components
        return color;//returns randomly generated color
    }
}
